package com.mycom.crawling190311;

import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		
		return "home";
	}
	
	@RequestMapping(value = "/selectContent", method = RequestMethod.GET)
	public @ResponseBody ArrayList<Object> selectContent(String some) {

		//Document 정보를 가져오는 객체
		Document doc = null;
		
		System.out.println(some);
		try {
			// 여러개의 url을 받아와서 동수의 doc를 만든다.(Elements도 마찬가지.)
			// 
			
			
			// https://news.naver.com/main/home.nhn   네이버 뉴스 메인페이지		
			// #main_content .com_list .mtype_list_wide  네이버 뉴스 메인 기사들
			
			
			//Jsoup의 connect를 통해 사이트의 html 정보를 가져온다.
			/*doc = Jsoup.connect("https://flapi.flipboard.com/content/v1/sections?uid=0&udid=0&tuuid=0&remoteid=flipboard%2Ftopic%2Finformationtechnology&limit=30&pageKey=flipboard-bNhJ1Y5tREKZi-TKgDld3g:a:16622281-1552348255").get();*/
			
			String myUrl = "https://news.naver.com/main/mainNews.nhn?sid1=300&firstLoad=Y";
			doc = Jsoup.connect(myUrl).ignoreContentType(true).get();
			
			System.out.println(doc);
			//			여긴 제대로 들어옴
			
		} catch (Exception e) {
			e.printStackTrace();
	}

		//ElementById처럼. select문을 통해 해당 태그를 id 정보를 가지고 찾아온다.
		//Elements elements = doc.select(".fx .container.centered .discover .m-t-2 .row m-t-2 .list.list-feed.col-xs-12.col-md-12.col-lg-12.col-xl-9 .list.list-feed .DiscoverFeed .DiscoverFeed__content .DiscoverFeed__actions .item-header");
		Elements elements = doc.select(".property");
		
		
		System.out.println("++++++" + elements);		// doc.select해온 부분의 내용을 보여줌
		
//		System.out.println(elements.toString());	// doc.select해온 부분의 html을 보여줌
		//여기 뭔가 잘못된거같다
		
		// realrank는 ol의 id
		/*Object [] elementArray= elements.toArray();
		
		for(Object test:elementArray) {
			System.out.println("+++++++++++++  "+test.toString());
		}*/
		//System.out.println(elements.toArray());
		
		//몇개인지 확인하려고 그냥 만듬
		int index = 0;
		
		//가져온 elements에 담기는 정보들을 ArrayList에 담기 위해 생성
		ArrayList<Object> result = new ArrayList<Object>();

		//forEach로 각각의 element의 text를 배열에 저장
		for (Element e : elements) {

//			System.out.print(++index);
//			System.out.println(e.text());
			
			result.add(e);
			
			System.out.println(++index);
			System.out.println(result + "\n");
		}

		
		//저장된 배열을 리턴
		return result;
	}
	
	
	
}
