package com.mycom.crawling190311.VO;

public class News {

}
